const pageLoader=document.querySelector('.page_loader')
const headerContainer=document.querySelector('.header_container')
const thirdButton=document.querySelectorAll('.third_button')
const thirdButtonSection=document.querySelectorAll('.third_button_section')

window.addEventListener('load',()=>{
    setTimeout(() => {
        pageLoader.style.display='none'
    }, 2000);
})

//////////////////////
const scrollUp=document.querySelector('.scroll_up')

window.addEventListener('scroll',()=>{
    if(window.scrollY>500){
        scrollUp.style.display='flex'
        headerContainer.style.background='rgba(0,0,0,0.8)'
    }else{
        scrollUp.style.display='none'
        headerContainer.style.background='none'
    }
    
})

scrollUp.addEventListener('click',()=>{
    window.scroll({
        top:0,
        behavior: "smooth"
    })
})

for(let i=0;i<thirdButton.length;i++){
    thirdButton[i].addEventListener('click',()=>{
        let checker=thirdButton[i].getAttribute('data-name')
        for(let i=0;i<thirdButtonSection.length;i++){
            let checkerName=thirdButtonSection[i].getAttribute('data-name')
            thirdButtonSection[0].classList.remove('active')
            if(checker===checkerName){
                thirdButtonSection[i].classList.add('show')
                thirdButtonSection[i].classList.remove('hide')
            }else{
                thirdButtonSection[i].classList.add('hide')
                thirdButtonSection[i].classList.remove('show')
            }
        }
    })
}

